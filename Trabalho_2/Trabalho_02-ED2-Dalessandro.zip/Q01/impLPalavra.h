typedef struct RLinhas rLinhas;

void InserirLista(rLinhas **NoListaLinhas, int NumLinha);
rLinhas* CriaLista(int NumLinha);
void ImprimirLista(rLinhas *NoListaLinhas);