typedef struct _Linhas Linhas;

void InsereNoLinha(Linhas **NoListaLinhas, int NumLinha);
Linhas* CriaNoLinha(int NumLinha);
void ImprimeListaLinhas(Linhas *NoListaLinhas);